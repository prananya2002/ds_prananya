
# Data Science Assignment — Sentiment vs Trader Behavior

## Contents
- `notebook_1.ipynb` — Main Colab notebook with full analysis.
- `csv_files/` — Input and processed CSV files.
- `outputs/` — Visualizations and charts.
- `ds_report.pdf` — Final report with findings and recommendations.

## How to Run
1. Open `notebook_1.ipynb` in Google Colab.
2. Ensure CSVs are in `csv_files/`.
3. Run cells sequentially to reproduce results.


# Data Science Assignment — Sentiment vs Trader Behavior

## Executive Summary
This analysis explored how trading behavior (profitability, leverage, volume, and win rate) varies between market sentiment states: Fear and Greed.

## Data Sources
1. Historical Trader Data (dummy — 500 rows).
2. Real Fear & Greed Index dataset (Bitcoin market sentiment).

## Methodology
- Data cleaning: standardized columns, parsed date/time, converted numeric fields.
- Merged sentiment with trade data by date.
- Aggregated daily metrics and created visualizations.
- Generated insights from statistical comparisons.

## Key Findings
- Trades during Greed periods had higher average PnL than during Fear.
- Leverage usage was higher during Greed vs Fear.
- Win rate was higher in Greed vs Fear.

## Recommendations
- Adjust leverage usage during high-risk sentiment periods.
- Review strategy performance during Fear periods for possible optimizations.
- Monitor win rate trends against sentiment shifts.

## Files Generated
- Processed CSVs in `csv_files/`
- Visual outputs in `outputs/`
- This report as `ds_report.pdf`
